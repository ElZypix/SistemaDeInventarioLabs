<?php
// model/php/CatalogoModelo.php — Catálogos administrables: sistemas operativos y software.

declare(strict_types=1);
require_once __DIR__ . '/../../config/conexionBD.php';

final class CatalogoModelo
{
    public const FAMILIAS = ['windows', 'linux', 'macos', 'otro'];

    /** Configuración de cada catálogo: tabla, tabla de relación, columna y campo extra. */
    private const CAT = [
        'so'       => ['tabla' => 'sistemas_operativos', 'rel' => 'equipo_so',       'col' => 'so_id',       'extra' => 'familia'],
        'software' => ['tabla' => 'software',            'rel' => 'equipo_software', 'col' => 'software_id', 'extra' => 'categoria'],
    ];

    private PDO $db;

    public function __construct()
    {
        $this->db = Conexion::obtener();
    }

    public static function valido(string $cat): bool
    {
        return isset(self::CAT[$cat]);
    }

    /** Lista con el número de equipos que usan cada elemento. */
    public function listar(string $cat): array
    {
        $c = self::CAT[$cat];
        $camposSO = $cat === 'so' ? ', t.distribucion, t.version' : '';
        $sql = "SELECT t.id, t.nombre, t.{$c['extra']} AS extra, t.activo$camposSO,
                       (SELECT COUNT(*) FROM {$c['rel']} r WHERE r.{$c['col']} = t.id) AS usos
                FROM {$c['tabla']} t ORDER BY t.{$c['extra']}, t.nombre";
        $out = [];
        foreach ($this->db->query($sql) as $r) {
            $out[] = [
                'id'            => (int)$r['id'],
                'nombre'        => $r['nombre'],
                $c['extra']     => $r['extra'],
                'activo'        => (int)$r['activo'] === 1,
                'usos'          => (int)$r['usos'],
            ];
            if ($cat === 'so') {
                $out[count($out) - 1]['distribucion'] = $r['distribucion'] ?: null;
                $out[count($out) - 1]['version'] = $r['version'] ?: null;
            }
        }
        // Orden siempre consistente (no depende de la intercalación de MySQL)
        if ($cat === 'so') {
            usort($out, static fn($a, $b) => self::claveOrdenSO($a) <=> self::claveOrdenSO($b));
        } else {
            usort($out, static fn($a, $b) => strnatcasecmp($a['categoria'], $b['categoria']) ?: strnatcasecmp($a['nombre'], $b['nombre']));
        }
        return $out;
    }

    public function idsExistentes(string $cat, array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if (!$ids) return [];
        $c = self::CAT[$cat];
        $in = implode(',', array_fill(0, count($ids), '?'));
        $st = $this->db->prepare("SELECT id FROM {$c['tabla']} WHERE id IN ($in)");
        $st->execute($ids);
        return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }

    public function existeNombre(string $cat, string $nombre, int $exceptoId = 0): bool
    {
        $c = self::CAT[$cat];
        $st = $this->db->prepare("SELECT COUNT(*) FROM {$c['tabla']} WHERE LOWER(nombre) = LOWER(?) AND id <> ?");
        $st->execute([$nombre, $exceptoId]);
        return (int)$st->fetchColumn() > 0;
    }

    public function guardar(string $cat, ?int $id, string $nombre, string $extra, bool $activo): int
    {
        $c = self::CAT[$cat];
        if ($id) {
            $this->db->prepare("UPDATE {$c['tabla']} SET nombre = ?, {$c['extra']} = ?, activo = ? WHERE id = ?")
                     ->execute([$nombre, $extra, $activo ? 1 : 0, $id]);
            return $id;
        }
        $this->db->prepare("INSERT INTO {$c['tabla']} (nombre, {$c['extra']}, activo) VALUES (?, ?, ?)")
                 ->execute([$nombre, $extra, $activo ? 1 : 0]);
        return (int)$this->db->lastInsertId();
    }

    public function usos(string $cat, int $id): int
    {
        $c = self::CAT[$cat];
        $st = $this->db->prepare("SELECT COUNT(*) FROM {$c['rel']} WHERE {$c['col']} = ?");
        $st->execute([$id]);
        return (int)$st->fetchColumn();
    }

    public function eliminar(string $cat, int $id): void
    {
        $c = self::CAT[$cat];
        $this->db->prepare("DELETE FROM {$c['tabla']} WHERE id = ?")->execute([$id]);
    }

    public function categoriasSoftware(): array
    {
        return $this->db->query('SELECT DISTINCT categoria FROM software ORDER BY categoria')->fetchAll(PDO::FETCH_COLUMN);
    }

    /* ---------------- Perfiles de software ---------------- */

    public function perfiles(): array
    {
        $out = [];
        foreach ($this->db->query('SELECT id, nombre FROM perfiles_software ORDER BY nombre') as $r) {
            $out[(int)$r['id']] = ['id' => (int)$r['id'], 'nombre' => $r['nombre'], 'software' => []];
        }
        foreach ($this->db->query('SELECT perfil_id, software_id FROM perfil_software') as $r) {
            if (isset($out[(int)$r['perfil_id']])) $out[(int)$r['perfil_id']]['software'][] = (int)$r['software_id'];
        }
        return array_values($out);
    }

    public function perfilExiste(int $id): bool
    {
        $st = $this->db->prepare('SELECT COUNT(*) FROM perfiles_software WHERE id = ?');
        $st->execute([$id]);
        return (int)$st->fetchColumn() > 0;
    }

    public function perfilNombreUsado(string $nombre, int $exceptoId = 0): bool
    {
        $st = $this->db->prepare('SELECT COUNT(*) FROM perfiles_software WHERE LOWER(nombre) = LOWER(?) AND id <> ?');
        $st->execute([$nombre, $exceptoId]);
        return (int)$st->fetchColumn() > 0;
    }

    public function guardarPerfil(?int $id, string $nombre, array $software): int
    {
        $this->db->beginTransaction();
        try {
            if ($id) {
                $this->db->prepare('UPDATE perfiles_software SET nombre = ? WHERE id = ?')->execute([$nombre, $id]);
            } else {
                $this->db->prepare('INSERT INTO perfiles_software (nombre) VALUES (?)')->execute([$nombre]);
                $id = (int)$this->db->lastInsertId();
            }
            $this->db->prepare('DELETE FROM perfil_software WHERE perfil_id = ?')->execute([$id]);
            $ins = $this->db->prepare('INSERT INTO perfil_software (perfil_id, software_id) VALUES (?, ?)');
            foreach (array_unique($software) as $sw) $ins->execute([$id, $sw]);
            $this->db->commit();
            return $id;
        } catch (Throwable $t) {
            $this->db->rollBack();
            throw $t;
        }
    }

    public function eliminarPerfil(int $id): void
    {
        $this->db->prepare('DELETE FROM perfiles_software WHERE id = ?')->execute([$id]);
    }

    /* ---------------- Sistemas operativos: familia / distribución / versión ---------------- */

    public const ORDEN_FAMILIA = ['windows' => 1, 'linux' => 2, 'macos' => 3, 'otro' => 4];

    /** Nombre visible: "Windows 11", "Ubuntu 24.04", "Zorin OS", "macOS Sequoia". */
    public static function nombreSO(string $familia, ?string $distro, ?string $version): string
    {
        $v = $version !== null && trim($version) !== '' ? trim($version) : null;
        return match ($familia) {
            'windows' => 'Windows' . ($v ? " $v" : ''),
            'macos'   => 'macOS' . ($v ? ' ' . trim((string)preg_replace('/\s*\(.*\)$/', '', $v)) : ''),
            default   => trim((string)$distro) . ($v ? " $v" : ''),
        };
    }

    /** Número de una versión para ordenar de la más nueva a la más vieja ("Sequoia (15)" → 15, "24.04" → 24.04). */
    public static function numeroVersion(?string $v): float
    {
        if ($v === null || $v === '') return INF; // sin versión va primero
        if (preg_match('/\(([\d.]+)\)/', $v, $m) || preg_match('/([\d.]+)/', $v, $m)) return (float)$m[1];
        return -1.0;
    }

    private static function claveOrdenSO(array $s): array
    {
        return [
            self::ORDEN_FAMILIA[$s['familia']] ?? 9,
            mb_strtolower((string)($s['distribucion'] ?? '')),
            -self::numeroVersion($s['version'] ?? null),
            mb_strtolower((string)($s['version'] ?? '')),
        ];
    }

    public function buscarSO(string $familia, ?string $distro, ?string $version): ?int
    {
        $st = $this->db->prepare("SELECT id FROM sistemas_operativos WHERE familia = ?
            AND LOWER(COALESCE(distribucion, '')) = LOWER(?) AND LOWER(COALESCE(version, '')) = LOWER(?)");
        $st->execute([$familia, (string)$distro, (string)$version]);
        $v = $st->fetchColumn();
        return $v === false ? null : (int)$v;
    }

    /** Guarda un sistema operativo calculando su nombre. Devuelve el id. */
    public function guardarSO(?int $id, string $familia, ?string $distro, ?string $version, bool $activo): int
    {
        $distro = in_array($familia, ['linux', 'otro'], true) ? $distro : null;
        $nombre = self::nombreSO($familia, $distro, $version);
        if ($id) {
            $this->db->prepare('UPDATE sistemas_operativos SET nombre = ?, familia = ?, distribucion = ?, version = ?, activo = ? WHERE id = ?')
                     ->execute([$nombre, $familia, $distro, $version, $activo ? 1 : 0, $id]);
            return $id;
        }
        $this->db->prepare('INSERT INTO sistemas_operativos (nombre, familia, distribucion, version, activo) VALUES (?, ?, ?, ?, ?)')
                 ->execute([$nombre, $familia, $distro, $version, $activo ? 1 : 0]);
        return (int)$this->db->lastInsertId();
    }

    /** Devuelve el id del sistema (familia, distro, versión); lo crea si no existe y lo reactiva si estaba inactivo. */
    public function asegurarSO(string $familia, ?string $distro, ?string $version): int
    {
        $id = $this->buscarSO($familia, $distro, $version);
        if ($id) {
            $this->db->prepare('UPDATE sistemas_operativos SET activo = 1 WHERE id = ?')->execute([$id]);
            return $id;
        }
        return $this->guardarSO(null, $familia, $distro, $version, true);
    }
}
