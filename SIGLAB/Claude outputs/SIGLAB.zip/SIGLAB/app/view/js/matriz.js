// view/js/matriz.js — Matriz de software: PCs × programas, con instalaciones pendientes.

import { api } from './api.js';
import { icono } from './iconos.js';
import { esc, toast, debounce } from './ui.js';
import { S, esAdmin, equipoPorId, equiposOrdenados, actualizarEquipos, norm } from './estado.js';
import { exportarExcel } from './exportar.js';

const cont = document.getElementById('matriz');
let labId = null;
let filtro = '';
let soloFaltantes = false;
let listo = false;

export function mostrarMatriz() {
  labId = labId ?? S.labId;
  if (!listo) { prepararEventos(); listo = true; }
  pintar(true);
}

function programasVisibles(eqs) {
  return S.software
    .filter((p) => p.activo && (!filtro || norm(p.nombre).includes(norm(filtro)) || norm(p.categoria).includes(norm(filtro))))
    .filter((p) => !soloFaltantes || eqs.some((e) => !e.software.includes(p.id)))
    .sort((a, b) => a.categoria.localeCompare(b.categoria) || a.nombre.localeCompare(b.nombre));
}

function pintar(animar = false) {
  const eqs = equiposOrdenados(labId);
  const progs = programasVisibles(eqs);
  const admin = esAdmin();
  const total = eqs.length || 1;

  cont.innerHTML = `
    <div class="matriz-barra">
      <div class="segmentado" id="mz-lab">${S.labs.map((l) => `<button data-lab="${l.id}" class="${l.id === labId ? 'sel' : ''}">${esc(l.nombre.replace(/^Laboratorio de /i, ''))}</button>`).join('')}</div>
      <div class="buscador-mini">${icono('buscar', 'sm')}<input class="input" id="mz-q" placeholder="Filtrar programas o categoría…" value="${esc(filtro)}"></div>
      <label class="switch"><input type="checkbox" id="mz-faltan" ${soloFaltantes ? 'checked' : ''}><span class="pista"></span>Solo con faltantes</label>
      <span class="espacio"></span>
      <button class="btn" id="mz-pdf">${icono('pdf', 'sm')} Instalaciones pendientes (PDF)</button>
      <button class="btn" id="mz-xlsx">${icono('excel', 'sm')} Excel</button>
    </div>
    ${!eqs.length || !progs.length ? `<div class="panel vacio-msg">${!eqs.length ? 'Este laboratorio no tiene equipos.' : 'Ningún programa coincide con el filtro.'}</div>` : `
    <div class="panel matriz-wrap ${animar ? 'entrando-mz' : ''}">
      <table class="matriz">
        <thead><tr>
          <th class="mz-pc">Equipo</th>
          ${progs.map((p, c) => `<th class="mz-prog" data-c="${c}" title="${esc(p.categoria)}"><span>${esc(p.nombre)}</span></th>`).join('')}
          <th class="mz-tot">Total</th>
        </tr></thead>
        <tbody>${eqs.map((e, r) => {
          const n = progs.filter((p) => e.software.includes(p.id)).length;
          return `<tr data-eq="${e.id}">
            <th class="mz-pc"><i class="punto st-${e.estado}"></i>${esc(e.numero)}</th>
            ${progs.map((p, c) => {
              const si = e.software.includes(p.id);
              return `<td data-c="${c}" style="--r:${r};--k:${c}"><button class="mz-celda ${si ? 'si' : 'no'}" data-sw="${p.id}" ${admin ? '' : 'disabled'}
                aria-label="${esc(p.nombre)} en ${esc(e.numero)}: ${si ? 'instalado' : 'falta'}">${si ? icono('check') : icono('x')}</button></td>`;
            }).join('')}
            <td class="mz-tot"><b>${n}</b>/${progs.length}</td>
          </tr>`;
        }).join('')}</tbody>
        <tfoot><tr>
          <th class="mz-pc">Instalado en</th>
          ${progs.map((p, c) => {
            const k = eqs.filter((e) => e.software.includes(p.id)).length;
            return `<td data-c="${c}" data-tot="${p.id}"><span class="mz-pct ${k === eqs.length ? 'lleno' : ''}"><i style="height:${(k / total) * 100}%"></i></span><small>${k}/${eqs.length}</small></td>`;
          }).join('')}
          <td></td>
        </tr></tfoot>
      </table>
    </div>
    <p class="ayuda">${admin ? 'Haz clic en una celda para marcar o desmarcar el programa en esa PC. Se guarda al instante.' : 'Vista de solo lectura.'}
      Los programas inactivos del catálogo no aparecen.</p>`}`;
}

function prepararEventos() {
  cont.addEventListener('click', async (ev) => {
    const lab = ev.target.closest('[data-lab]');
    if (lab) { labId = Number(lab.dataset.lab); pintar(true); return; }
    if (ev.target.closest('#mz-pdf')) {
      const eqs = equiposOrdenados(labId);
      const ids = programasVisibles(eqs).map((p) => p.id).join(',');
      window.open(`ctrl/php/reporteSoftware.php?lab=${labId}&sw=${ids}`, '_blank', 'noopener');
      return;
    }
    if (ev.target.closest('#mz-xlsx')) { exportarExcel(ev.target.closest('#mz-xlsx')); return; }

    const celda = ev.target.closest('.mz-celda');
    if (!celda || celda.disabled) return;
    const fila = celda.closest('tr');
    const e = equipoPorId(Number(fila.dataset.eq));
    const sw = Number(celda.dataset.sw);
    const instalar = !e.software.includes(sw);
    // Optimista: se pinta al momento y se revierte si falla
    e.software = instalar ? [...e.software, sw] : e.software.filter((x) => x !== sw);
    pintarCelda(celda, instalar);
    actualizarTotales(fila, sw);
    try {
      const r = await api('ctrl/php/inventarioApi.php?accion=ponerSoftware', { body: { equipo_id: e.id, software_id: sw, instalado: instalar } });
      actualizarEquipos([r.equipo]);
    } catch (err) {
      e.software = instalar ? e.software.filter((x) => x !== sw) : [...e.software, sw];
      pintarCelda(celda, !instalar);
      actualizarTotales(fila, sw);
      toast(err.message, 'error');
    }
  });
  cont.addEventListener('input', debounce((ev) => {
    if (ev.target.id !== 'mz-q') return;
    filtro = ev.target.value;
    const pos = ev.target.selectionStart;
    pintar();
    const q = document.getElementById('mz-q'); q.focus(); q.setSelectionRange(pos, pos);
  }, 180));
  cont.addEventListener('change', (ev) => {
    if (ev.target.id === 'mz-faltan') { soloFaltantes = ev.target.checked; pintar(true); }
  });
  // Resalta la columna bajo el cursor
  cont.addEventListener('pointerover', (ev) => {
    const c = ev.target.closest('[data-c]')?.dataset.c;
    cont.querySelectorAll('.col-hover').forEach((x) => x.classList.remove('col-hover'));
    if (c !== undefined) cont.querySelectorAll(`[data-c="${c}"]`).forEach((x) => x.classList.add('col-hover'));
  });
  cont.addEventListener('pointerleave', () => cont.querySelectorAll('.col-hover').forEach((x) => x.classList.remove('col-hover')));
}

function pintarCelda(celda, si) {
  celda.className = `mz-celda ${si ? 'si' : 'no'}`;
  celda.innerHTML = si ? icono('check') : icono('x');
  celda.animate([{ transform: 'scale(.6)' }, { transform: 'scale(1.15)' }, { transform: 'scale(1)' }], { duration: 300, easing: 'cubic-bezier(.34,1.56,.64,1)' });
}

function actualizarTotales(fila, sw) {
  const eqs = equiposOrdenados(labId);
  const progs = programasVisibles(eqs);
  const e = equipoPorId(Number(fila.dataset.eq));
  fila.querySelector('td.mz-tot').innerHTML = `<b>${progs.filter((p) => e.software.includes(p.id)).length}</b>/${progs.length}`;
  const tot = cont.querySelector(`[data-tot="${sw}"]`);
  if (!tot) return;
  const k = eqs.filter((x) => x.software.includes(sw)).length;
  tot.querySelector('i').style.height = `${(k / (eqs.length || 1)) * 100}%`;
  tot.querySelector('.mz-pct').classList.toggle('lleno', k === eqs.length);
  tot.querySelector('small').textContent = `${k}/${eqs.length}`;
}
