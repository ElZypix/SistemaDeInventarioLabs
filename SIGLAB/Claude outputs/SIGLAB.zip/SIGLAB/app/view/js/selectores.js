// view/js/selectores.js — Selectores reutilizables de SIGLAB:
//   selectorSO()        sistema operativo en cascada (familia → distribución → versión), con arranque dual
//   selectorSoftware()  programas con búsqueda y etiquetas, con alta rápida al catálogo
//   nombreSO()          nombre visible igual que en el servidor

import { api } from './api.js';
import { icono } from './iconos.js';
import { esc, el, toast, abrirModal, conCarga, agitar } from './ui.js';
import { S, FAMILIAS, soPorId } from './estado.js';
import { combobox, multiCombo } from './combobox.js';

const ORDEN_FAM = { windows: 1, linux: 2, macos: 3, otro: 4 };

export function nombreSO(familia, distro, version) {
  const v = (version || '').trim();
  if (familia === 'windows') return `Windows${v ? ` ${v}` : ''}`;
  if (familia === 'macos') return `macOS${v ? ` ${v.replace(/\s*\(.*\)$/, '')}` : ''}`;
  return `${(distro || '').trim()}${v ? ` ${v}` : ''}`;
}

/** "Sequoia (15)" → 15, "24.04" → 24.04; sin número → -1 */
const numVersion = (v) => { const m = /\(([\d.]+)\)/.exec(v) || /([\d.]+)/.exec(v); return m ? parseFloat(m[1]) : -1; };
const porVersion = (a, b) => numVersion(b) - numVersion(a) || a.localeCompare(b, 'es', { numeric: true });
const igual = (a, b) => (a || '').trim().toLowerCase() === (b || '').trim().toLowerCase();

const buscarSO = (f, d, v) => S.so.find((s) => s.familia === f && igual(s.distribucion, d) && igual(s.version, v));

async function asegurarSO(f, d, v) {
  const r = await api('ctrl/php/catalogosApi.php?tipo=so&accion=asegurar', { body: { familia: f, distribucion: d || '', version: v || '' } });
  S.so = r.items;
  return r.item;
}

/* ================================================================== */
/*  Sistema operativo en cascada                                       */
/* ================================================================== */

/**
 * opc = { ids: number[], admin: bool, alCambiar?() , grande?: bool }
 * Devuelve { el, obtenerIds: async () => number[], vacio: () => bool }
 */
export function selectorSO(opc) {
  const filas = (opc.ids || []).map(soPorId).filter(Boolean)
    .sort((a, b) => (ORDEN_FAM[a.familia] || 9) - (ORDEN_FAM[b.familia] || 9))
    .map((s) => ({ familia: s.familia, distro: s.distribucion || '', version: s.version || '' }));
  if (!filas.length) filas.push({ familia: '', distro: '', version: '' });

  const raiz = el(`<div class="sel-so ${opc.grande ? 'grande' : ''}"><div class="sel-so-filas"></div>
      ${opc.admin ? `<button type="button" class="enlace" data-mas>${icono('mas', 'sm')} Agregar otro sistema (arranque dual)</button>` : ''}</div>`);
  const cont = raiz.querySelector('.sel-so-filas');

  const familias = () => [
    { valor: '', texto: 'Sin sistema', tenue: true },
    ...Object.entries(FAMILIAS).map(([k, t]) => ({ valor: k, texto: t, icono: k })),
  ];
  const distros = (f) => [...new Set(S.so.filter((s) => s.familia === f && s.distribucion && (s.activo || filas.some((x) => igual(x.distro, s.distribucion))))
    .map((s) => s.distribucion))].sort((a, b) => a.localeCompare(b, 'es', { numeric: true }))
    .map((d) => ({ valor: d, texto: d }));
  const versiones = (f, d) => [
    { valor: '', texto: 'Sin especificar', tenue: true },
    ...[...new Set(S.so.filter((s) => s.familia === f && s.version && (f === 'linux' || f === 'otro' ? igual(s.distribucion, d) : true)
      && (s.activo || filas.some((x) => igual(x.version, s.version)))).map((s) => s.version))]
      .sort(porVersion).map((v) => ({ valor: v, texto: v })),
  ];

  function pintar(animarFila = -1, animarNivel = '') {
    cont.innerHTML = '';
    let siguiente = null;   // combobox que se abre solo tras elegir el nivel anterior
    filas.forEach((fila, i) => {
      const fil = el(`<div class="sel-so-fila"></div>`);
      const cambiar = () => opc.alCambiar?.();
      fil.append(combobox({
        placeholder: 'Sistema…', valor: fila.familia, opciones: familias, deshabilitado: !opc.admin, clase: 'cbx-fam',
        alElegir: (v) => { if (v !== fila.familia) { fila.familia = v; fila.distro = ''; fila.version = ''; pintar(i, 'd'); cambiar(); } },
      }).el);
      const conDistro = fila.familia === 'linux' || fila.familia === 'otro';
      if (conDistro) {
        const cbD = combobox({
          placeholder: fila.familia === 'linux' ? 'Distribución…' : 'Nombre del sistema…',
          valor: fila.distro, opciones: () => distros(fila.familia), deshabilitado: !opc.admin,
          animar: animarFila === i && animarNivel === 'd',
          otro: opc.admin ? {
            texto: fila.familia === 'linux' ? 'Otra distribución…' : 'Otro sistema…',
            placeholder: fila.familia === 'linux' ? 'Ej. Fedora, Kali Linux, Pop!_OS' : 'Ej. ChromeOS Flex, FreeBSD',
            alAgregar: async (t) => { const it = await asegurarSO(fila.familia, t, ''); toast(`"${it.nombre}" agregado al catálogo.`); return it.distribucion; },
          } : null,
          alElegir: (v) => { if (v !== fila.distro) { fila.distro = v; fila.version = ''; pintar(i, 'v'); cambiar(); } },
        });
        fil.append(cbD.el);
        if (animarFila === i && animarNivel === 'd') siguiente = cbD;
      }
      if (fila.familia && (!conDistro || fila.distro)) {
        const cbV = combobox({
          placeholder: 'Versión (opcional)', valor: fila.version, opciones: () => versiones(fila.familia, fila.distro), deshabilitado: !opc.admin,
          animar: animarFila === i && (animarNivel === 'v' || (animarNivel === 'd' && !conDistro)),
          otro: opc.admin ? {
            texto: 'Otra versión…',
            placeholder: fila.familia === 'macos' ? 'Ej. Monterey (12)' : fila.familia === 'windows' ? 'Ej. 7' : 'Ej. 25.04',
            alAgregar: async (t) => { const it = await asegurarSO(fila.familia, fila.distro, t); toast(`"${it.nombre}" agregado al catálogo.`); return it.version; },
          } : null,
          alElegir: (v) => { fila.version = v; cambiar(); },
        });
        fil.append(cbV.el);
        if (animarFila === i && (animarNivel === 'v' || (animarNivel === 'd' && !conDistro))) siguiente = cbV;
      }
      if (opc.admin && filas.length > 1) {
        const b = el(`<button type="button" class="btn sm icon fantasma" aria-label="Quitar este sistema">${icono('basura', 'sm')}</button>`);
        b.onclick = () => { filas.splice(i, 1); pintar(); cambiar(); };
        fil.append(b);
      }
      cont.append(fil);
    });
    if (siguiente && opc.admin) setTimeout(() => siguiente.foco(true), 60);
  }
  pintar();

  raiz.querySelector('[data-mas]')?.addEventListener('click', () => {
    filas.push({ familia: '', distro: '', version: '' });
    pintar(filas.length - 1);
    const ult = cont.lastElementChild;
    ult.classList.add('cbx-entra');
    ult.querySelector('input')?.focus();
    opc.alCambiar?.();
  });

  return {
    el: raiz,
    /** Ids de catálogo para guardar; crea en el catálogo las combinaciones nuevas. */
    async obtenerIds() {
      const ids = [];
      for (const f of filas) {
        if (!f.familia) continue;
        if ((f.familia === 'linux' || f.familia === 'otro') && !f.distro) continue;
        let s = buscarSO(f.familia, f.distro, f.version);
        if (!s) s = await asegurarSO(f.familia, f.distro, f.version);
        if (s && !ids.includes(s.id)) ids.push(s.id);
      }
      return ids;
    },
    incompletos: () => filas.some((f) => (f.familia === 'linux' || f.familia === 'otro') && !f.distro),
  };
}

/* ================================================================== */
/*  Software                                                           */
/* ================================================================== */

/** Alta rápida de un programa: pide la categoría con un combobox (o "Otra…"). */
export function agregarProgramaRapido(nombre) {
  return new Promise((resolve) => {
    let categoria = 'General';
    let resultado = null;
    const cats = () => [...new Set(S.software.map((s) => s.categoria).concat('General'))]
      .sort((a, b) => a.localeCompare(b, 'es')).map((c) => ({ valor: c, texto: c }));
    const cuerpo = el(`<div style="display:contents">
      <div class="campo"><label>Programa</label><input class="input" id="ap-nombre" maxlength="80" value="${esc(nombre)}"></div>
      <div class="campo"><span class="etiqueta">Categoría</span><div id="ap-cat"></div></div>
    </div>`);
    const cb = combobox({ placeholder: 'Categoría…', valor: categoria, opciones: cats,
      otro: { texto: 'Otra categoría…', placeholder: 'Ej. Diseño, Seguridad', alAgregar: async (t) => t },
      alElegir: (v) => { categoria = v; } });
    cuerpo.querySelector('#ap-cat').append(cb.el);
    const pie = el(`<div style="display:contents"><span class="espacio"></span><button class="btn" data-c>Cancelar</button><button class="btn primario" data-ok>${icono('mas', 'sm')} Agregar</button></div>`);
    const m = abrirModal({ titulo: 'Agregar programa al catálogo', cuerpo, pie, ancho: 440, alCerrar: () => resolve(resultado) });
    pie.querySelector('[data-c]').onclick = () => m.cerrar();
    const ok = pie.querySelector('[data-ok]');
    ok.onclick = () => conCarga(ok, async () => {
      try {
        const r = await api('ctrl/php/catalogosApi.php?tipo=software&accion=guardar', { body: { nombre: cuerpo.querySelector('#ap-nombre').value, categoria: cb.valor || categoria } });
        S.software = r.items;
        resultado = r.item.id;
        toast(r.mensaje);
        m.cerrar();
      } catch (err) { toast(err.message, 'error'); agitar(m.modal); }
    });
  });
}

/**
 * opc = { seleccion: Set<number>, admin, alCambiar?(), placeholder? }
 */
export function selectorSoftware(opc) {
  return multiCombo({
    placeholder: opc.placeholder || 'Buscar programa…',
    seleccion: opc.seleccion,
    deshabilitado: !opc.admin,
    vacioTexto: 'Sin programas registrados',
    opciones: () => S.software.filter((s) => s.activo || opc.seleccion.has(s.id))
      .map((s) => ({ valor: s.id, texto: s.nombre, grupo: s.categoria })),
    agregar: opc.admin ? { alAgregar: (t) => agregarProgramaRapido(t) } : null,
    alCambiar: opc.alCambiar,
  });
}

/** Menú pequeño "Aplicar perfil ▾". `alAplicar(perfil)` */
export function botonPerfiles(alAplicar, etiqueta = 'Aplicar perfil') {
  const cont = el(`<div class="menu-perfiles"><button type="button" class="btn sm">${icono('capas', 'sm')} ${esc(etiqueta)} ${icono('flecha', 'sm')}</button><div class="menu-perfiles-lista" hidden></div></div>`);
  const btn = cont.querySelector('button');
  const lista = cont.querySelector('.menu-perfiles-lista');
  btn.onclick = (e) => {
    e.stopPropagation();
    if (!lista.hidden) { lista.hidden = true; return; }
    lista.innerHTML = S.perfiles.length
      ? S.perfiles.map((p) => `<button type="button" data-p="${p.id}">${esc(p.nombre)}<small>${p.software.length} programas</small></button>`).join('')
      : '<span class="ayuda" style="padding:8px">No hay perfiles. Créalos en Catálogos.</span>';
    lista.hidden = false;
  };
  lista.onclick = (e) => {
    const b = e.target.closest('[data-p]'); if (!b) return;
    lista.hidden = true;
    alAplicar(S.perfiles.find((x) => x.id === Number(b.dataset.p)));
  };
  document.addEventListener('click', () => { lista.hidden = true; });
  return cont;
}
