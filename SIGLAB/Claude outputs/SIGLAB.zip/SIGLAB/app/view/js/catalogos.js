// view/js/catalogos.js — Administración de sistemas operativos y software.

import { api } from './api.js';
import { icono } from './iconos.js';
import { esc, el, toast, abrirModal, confirmar, conCarga, agitar } from './ui.js';
import { S, FAMILIAS } from './estado.js';

const cont = document.getElementById('catalogos');

const CONF = {
  so: { titulo: 'Sistemas operativos', singular: 'sistema operativo', extra: 'familia', extraTxt: 'Familia', ph: 'Ej. Fedora, Windows 10 LTSC' },
  software: { titulo: 'Software', singular: 'programa', extra: 'categoria', extraTxt: 'Categoría', ph: 'Ej. Blender, GNS3, Postman' },
};

export async function mostrarCatalogos() {
  cont.innerHTML = `${panel('so')}${panel('software')}
    <section class="panel ancho" id="cat-perfiles">
      <div class="panel-head"><h3>${icono('capas')} Perfiles de software</h3>
        <button class="btn sm primario" id="btn-nuevo-perfil">${icono('mas', 'sm')} Nuevo perfil</button></div>
      <div class="perfiles-lista"><div class="vacio-msg">Cargando…</div></div>
    </section>`;
  await Promise.all(['so', 'software'].map(cargar));
  const r = await api('ctrl/php/perfilesApi.php?accion=listar');
  S.perfiles = r.perfiles;
  pintarPerfiles();
}

function pintarPerfiles(nuevoId = null) {
  const caja = document.querySelector('#cat-perfiles .perfiles-lista');
  if (!caja) return;
  caja.innerHTML = S.perfiles.length ? S.perfiles.map((p) => `
    <article class="perfil-card ${p.id === nuevoId ? 'fila-nueva' : ''}" data-perfil="${p.id}">
      <div class="perfil-top"><b>${esc(p.nombre)}</b><span class="badge">${p.software.length} programas</span>
        <span class="espacio"></span>
        <button class="btn sm icon fantasma" data-editar-perfil title="Editar">${icono('editar', 'sm')}</button>
        <button class="btn sm icon fantasma peligro" data-borrar-perfil title="Eliminar">${icono('basura', 'sm')}</button></div>
      <div class="chips">${p.software.map((id) => S.software.find((x) => x.id === id)).filter(Boolean).map((x) => `<span class="chip" aria-disabled="true">${esc(x.nombre)}</span>`).join('')}</div>
    </article>`).join('')
    : '<div class="vacio-msg">Aún no hay perfiles. Crea uno con los programas que instalas siempre juntos.</div>';
}

function formPerfil(p) {
  const sel = new Set(p?.software || []);
  const cuerpo = el(`<div style="display:contents">
    <div class="campo"><label for="pf-nombre">Nombre del perfil</label><input class="input" id="pf-nombre" maxlength="80" value="${esc(p?.nombre || '')}" placeholder="Ej. Imagen Desarrollo 2026"></div>
    <div class="campo"><span class="etiqueta">Programas <small id="pf-n" style="font-weight:500;color:var(--texto-3)"></small></span>
      <div class="sw-caja" id="pf-sw"></div></div>
  </div>`);
  const pintar = () => {
    const lista = S.software.filter((x) => x.activo || sel.has(x.id));
    const cats = [...new Set(lista.map((x) => x.categoria))];
    cuerpo.querySelector('#pf-sw').innerHTML = cats.map((c) => `<div class="sw-cat">${esc(c)}</div><div class="chips">${lista.filter((x) => x.categoria === c)
      .map((x) => `<button type="button" class="chip ${sel.has(x.id) ? 'on' : ''}" data-id="${x.id}">${esc(x.nombre)}${sel.has(x.id) ? icono('check', 'sm') : ''}</button>`).join('')}</div>`).join('');
    cuerpo.querySelector('#pf-n').textContent = `· ${sel.size} marcados`;
  };
  pintar();
  cuerpo.querySelector('#pf-sw').addEventListener('click', (e) => {
    const b = e.target.closest('[data-id]'); if (!b) return;
    const id = Number(b.dataset.id);
    sel.has(id) ? sel.delete(id) : sel.add(id);
    pintar();
  });
  const pie = el(`<div style="display:contents"><span class="espacio"></span><button class="btn" data-c>Cancelar</button><button class="btn primario" data-ok>Guardar perfil</button></div>`);
  const m = abrirModal({ titulo: p ? 'Editar perfil' : 'Nuevo perfil de software', subtitulo: 'Un conjunto de programas que se aplica de un clic', cuerpo, pie, ancho: 620 });
  pie.querySelector('[data-c]').onclick = () => m.cerrar();
  const ok = pie.querySelector('[data-ok]');
  ok.onclick = () => conCarga(ok, async () => {
    try {
      const antes = new Set(S.perfiles.map((x) => x.id));
      const r = await api('ctrl/php/perfilesApi.php?accion=guardar', { body: { id: p?.id, nombre: cuerpo.querySelector('#pf-nombre').value, software: [...sel] } });
      S.perfiles = r.perfiles;
      pintarPerfiles(S.perfiles.find((x) => !antes.has(x.id))?.id ?? p?.id);
      toast(r.mensaje);
      m.cerrar();
    } catch (err) { toast(err.message, 'error'); agitar(m.modal); }
  });
}

function panel(tipo) {
  const c = CONF[tipo];
  return `<section class="panel" id="cat-${tipo}">
    <div class="panel-head"><h3>${icono(tipo === 'so' ? 'windows' : 'software')} ${c.titulo}</h3><span class="badge" data-total>…</span></div>
    <form class="cat-form" data-tipo="${tipo}">
      ${tipo === 'so' ? camposSO() : `<input class="input" name="nombre" placeholder="${c.ph}" maxlength="80" aria-label="Nombre" required>
      ${extraCampo(tipo)}`}
      <button class="btn primario" type="submit">${icono('mas', 'sm')} Agregar</button>
    </form>
    <div class="tabla-wrap"><div class="vacio-msg">Cargando…</div></div>
  </section>`;
}

function alternarDistro(sel) {
  const dist = sel.parentElement.querySelector('[name=distribucion]');
  const con = sel.value === 'linux' || sel.value === 'otro';
  dist.placeholder = sel.value === 'otro' ? 'Nombre del sistema' : 'Distribución, ej. Fedora';
  if (con && dist.hidden) { dist.hidden = false; dist.animate([{ opacity: 0, transform: 'translateX(-8px)' }, { opacity: 1, transform: 'none' }], { duration: 220 }); }
  if (!con) dist.hidden = true;
}

/** Campos de un sistema operativo: familia, distribución (Linux/otro) y versión opcional. */
function camposSO(it = null) {
  const f = it?.familia || 'windows';
  const conDistro = f === 'linux' || f === 'otro';
  return `<select class="select" name="familia" aria-label="Familia" style="width:130px;flex:none">${Object.entries(FAMILIAS).map(([k, v]) => `<option value="${k}" ${k === f ? 'selected' : ''}>${v}</option>`).join('')}</select>
    <input class="input campo-distro" name="distribucion" maxlength="60" placeholder="${f === 'otro' ? 'Nombre del sistema' : 'Distribución, ej. Fedora'}" value="${esc(it?.distribucion || '')}" ${conDistro ? '' : 'hidden'} aria-label="Distribución">
    <input class="input" name="version" maxlength="40" placeholder="Versión (opcional)" value="${esc(it?.version || '')}" aria-label="Versión" style="width:170px;flex:none">`;
}

function extraCampo(tipo, valor = '') {
  if (tipo === 'so') {
    return `<select class="select" name="extra" aria-label="Familia">${Object.entries(FAMILIAS).map(([k, v]) => `<option value="${k}" ${k === valor ? 'selected' : ''}>${v}</option>`).join('')}</select>`;
  }
  const cats = [...new Set(S.software.map((s) => s.categoria).concat(['General']))].sort();
  return `<input class="input" name="extra" list="dl-cat-sw" placeholder="Categoría" value="${esc(valor)}" style="flex:0 0 190px" aria-label="Categoría">
    <datalist id="dl-cat-sw">${cats.map((x) => `<option value="${esc(x)}">`).join('')}</datalist>`;
}

async function cargar(tipo) {
  const r = await api(`ctrl/php/catalogosApi.php?tipo=${tipo}&accion=listar`);
  if (tipo === 'so') S.so = r.items; else S.software = r.items;
  pintar(tipo);
}

function pintar(tipo, nuevoId = null) {
  const c = CONF[tipo];
  const items = tipo === 'so' ? S.so : S.software;
  const sec = document.getElementById(`cat-${tipo}`);
  sec.querySelector('[data-total]').textContent = `${items.filter((x) => x.activo).length} activos`;
  let grupo = null;
  const cabGrupo = (it) => {
    const g = tipo === 'so' ? it.familia : it.categoria;
    if (g === grupo) return '';
    grupo = g;
    return `<tr class="fila-grupo"><td colspan="${tipo === 'so' ? 4 : 5}">${tipo === 'so' ? `${icono(g, 'sm')} ${FAMILIAS[g]}` : esc(g)}</td></tr>`;
  };
  sec.querySelector('.tabla-wrap').innerHTML = items.length ? `
    <table class="tabla">
      <thead><tr><th>Nombre</th>${tipo === 'so' ? '' : `<th>${c.extraTxt}</th>`}<th>Equipos</th><th>Activo</th><th></th></tr></thead>
      <tbody>${items.map((it) => `${cabGrupo(it)}
        <tr class="${it.activo ? '' : 'inactivo'} ${it.id === nuevoId ? 'fila-nueva' : ''}" data-id="${it.id}">
          <td><b>${esc(it.nombre)}</b></td>
          ${tipo === 'so' ? '' : `<td>${esc(it.categoria)}</td>`}
          <td>${it.usos}</td>
          <td><label class="switch" title="${it.activo ? 'Desactivar: deja de aparecer para asignar' : 'Activar'}"><input type="checkbox" data-activo ${it.activo ? 'checked' : ''}><span class="pista"></span></label></td>
          <td class="acciones">
            <button class="btn sm icon fantasma" data-editar title="Editar">${icono('editar', 'sm')}</button>
            <button class="btn sm icon fantasma peligro" data-borrar title="${it.usos ? 'En uso: desactívalo en lugar de eliminarlo' : 'Eliminar'}" ${it.usos ? 'disabled' : ''}>${icono('basura', 'sm')}</button>
          </td>
        </tr>`).join('')}</tbody>
    </table>` : '<div class="vacio-msg">Sin elementos todavía.</div>';
}

async function guardar(tipo, datos) {
  const body = tipo === 'so'
    ? { id: datos.id, familia: datos.familia, distribucion: datos.distribucion || '', version: datos.version || '', activo: datos.activo }
    : { id: datos.id, nombre: datos.nombre, activo: datos.activo, [CONF[tipo].extra]: datos.extra };
  const r = await api(`ctrl/php/catalogosApi.php?tipo=${tipo}&accion=guardar`, { body });
  if (tipo === 'so') S.so = r.items; else S.software = r.items;
  pintar(tipo, r.item?.id);
  return r;
}

cont.addEventListener('submit', (e) => {
  e.preventDefault();
  const f = e.target;
  const tipo = f.dataset.tipo;
  const btn = f.querySelector('button[type=submit]');
  conCarga(btn, async () => {
    try {
      const r = tipo === 'so'
        ? await guardar('so', { familia: f.familia.value, distribucion: f.distribucion.value, version: f.version.value, activo: true })
        : await guardar(tipo, { nombre: f.nombre.value, extra: f.extra.value, activo: true });
      toast(r.mensaje);
      if (tipo === 'so') { f.version.value = ''; f.version.focus(); } else { f.nombre.value = ''; f.extra.value = ''; f.nombre.focus(); }
    } catch (err) { toast(err.message, 'error'); }
  });
});

cont.addEventListener('change', async (e) => {
  // Familia del formulario de SO: muestra u oculta la distribución con animación
  if (e.target.name === 'familia') { alternarDistro(e.target); return; }
  if (!e.target.matches('[data-activo]')) return;
  const tr = e.target.closest('tr');
  const sec = e.target.closest('section');
  const tipo = sec.id.replace('cat-', '');
  const it = (tipo === 'so' ? S.so : S.software).find((x) => x.id === Number(tr.dataset.id));
  try {
    await guardar(tipo, { ...it, extra: it[CONF[tipo].extra], activo: e.target.checked });
    toast(e.target.checked ? `"${it.nombre}" activado.` : `"${it.nombre}" desactivado. Ya no aparecerá para asignar.`);
  } catch (err) { toast(err.message, 'error'); e.target.checked = !e.target.checked; }
});

cont.addEventListener('click', async (e) => {
  if (e.target.closest('#btn-nuevo-perfil')) { formPerfil(null); return; }
  const tarjeta = e.target.closest('.perfil-card');
  if (tarjeta) {
    const p = S.perfiles.find((x) => x.id === Number(tarjeta.dataset.perfil));
    if (e.target.closest('[data-editar-perfil]')) formPerfil(p);
    if (e.target.closest('[data-borrar-perfil]')) {
      if (!await confirmar({ titulo: 'Eliminar perfil', mensaje: `¿Eliminar el perfil <b>${esc(p.nombre)}</b>? Los programas instalados en las PCs no se modifican.`, aceptar: 'Eliminar', peligro: true })) return;
      try {
        const r = await api('ctrl/php/perfilesApi.php?accion=eliminar', { body: { id: p.id } });
        S.perfiles = r.perfiles; pintarPerfiles(); toast(r.mensaje);
      } catch (err) { toast(err.message, 'error'); }
    }
    return;
  }
  const b = e.target.closest('[data-editar], [data-borrar]');
  if (!b) return;
  const tr = b.closest('tr');
  const tipo = b.closest('section').id.replace('cat-', '');
  const c = CONF[tipo];
  const it = (tipo === 'so' ? S.so : S.software).find((x) => x.id === Number(tr.dataset.id));

  if (b.dataset.borrar !== undefined) {
    if (!await confirmar({ titulo: `Eliminar ${c.singular}`, mensaje: `¿Eliminar <b>${esc(it.nombre)}</b> del catálogo?`, aceptar: 'Eliminar', peligro: true })) return;
    try {
      const r = await api(`ctrl/php/catalogosApi.php?tipo=${tipo}&accion=eliminar`, { body: { id: it.id } });
      if (tipo === 'so') S.so = r.items; else S.software = r.items;
      pintar(tipo);
      toast(r.mensaje);
    } catch (err) { toast(err.message, 'error'); }
    return;
  }

  const cuerpo = el(`<form style="display:contents">
      ${tipo === 'so' ? `<div class="campo"><span class="etiqueta">Familia, distribución y versión</span><div class="fila-flex">${camposSO(it)}</div>
        <span class="ayuda">El nombre se arma solo, ej. "Ubuntu 24.04" o "macOS Sequoia".</span></div>` : `
      <div class="campo"><label>Nombre</label><input class="input" name="nombre" value="${esc(it.nombre)}" maxlength="80"></div>
      <div class="campo"><label>${c.extraTxt}</label><div class="fila-flex">${extraCampo(tipo, it[c.extra])}</div></div>`}
      ${it.usos ? `<p class="ayuda" style="margin:0">Está asignado a ${it.usos} equipo${it.usos === 1 ? '' : 's'}; el cambio de nombre se verá en todos.</p>` : ''}
    </form>`);
  cuerpo.addEventListener('change', (ev) => { if (ev.target.name === 'familia') alternarDistro(ev.target); });
  const pie = el(`<div style="display:contents"><span class="espacio"></span><button class="btn" data-c>Cancelar</button><button class="btn primario" data-ok>Guardar</button></div>`);
  const m = abrirModal({ titulo: `Editar ${c.singular}`, cuerpo, pie, ancho: 460 });
  pie.querySelector('[data-c]').onclick = () => m.cerrar();
  const ok = pie.querySelector('[data-ok]');
  const enviar = () => conCarga(ok, async () => {
    try {
      const q = (n) => cuerpo.querySelector(`[name=${n}]`)?.value;
      const r = tipo === 'so'
        ? await guardar('so', { id: it.id, familia: q('familia'), distribucion: q('distribucion'), version: q('version'), activo: it.activo })
        : await guardar(tipo, { id: it.id, nombre: q('nombre'), extra: q('extra'), activo: it.activo });
      toast(r.mensaje);
      m.cerrar();
    } catch (err) { toast(err.message, 'error'); agitar(m.modal); }
  });
  ok.onclick = enviar;
  cuerpo.addEventListener('submit', (ev) => { ev.preventDefault(); enviar(); });
});
